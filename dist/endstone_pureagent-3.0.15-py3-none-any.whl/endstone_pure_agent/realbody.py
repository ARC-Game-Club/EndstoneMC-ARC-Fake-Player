"""真实假人动作的步骤处理器。

`BatchExecutor` 原本假设"一步 = 一次同步 API 调用"。接入真假人之后，
有几类步骤变成了"发起之后要等物理世界"：

    walk_to     让假人真的走过去（原版寻路，会爬坡绕树）
    dig_far     走过去再挖（够不着的时候）
    dig_near    直接挖（已经在手够得着的范围内）
    place_real  用假人的手放置方块

这里统一用 **"发起 + 等结果"** 两步式处理。

难点在于 `BatchExecutor` 的处理器返回值**只有两个**：

    True  → 这一步成功了
    False → 还没结论，执行器原地下次再来问

而真实动作需要表达**三件事**："还没完"、"成了"、"**试够了，就是做不成**"。
这个差异是本模块所有坑的源头，处理办法是：

  · "还没完" → `return False`（执行器下一 tick 再来问）
  · "成了"   → `return True`
  · "做不成" → 挂 `_gave_up` 标记并 **`return True`**（见 `_give_up`）

第三条看起来别扭（失败却返回 True），但它是**唯一**能让计划正常结算的
写法：False 会被解释成"还在进行中"，计划既不推进也不结算，
`Agent._inflight` 永不释放，`should_think()` 那道闸就此锁死 ——
智能体从此不再思考第二次，而且**一行日志都不打**。
翻译工作由 `plugin._real_or_retry` 完成：它读到 `_gave_up` 标记，
把这次"有结论的失败"记成计划的一次重试，额度用尽就交给执行器结算。

判定"这一步到底成了没有"的依据是：

  · `BodyController` 保留的 `last_dig` / `last_walk`（**权威结论**，
    比查方块状态准，因为它能区分"被别的动作挖掉了"和"我挖的"）
  · 三张互不替代的记账表：`_attempts`（本轮进行中）、`_tries`（累计
    失败次数）、`_started`（曾经开始过）。**别把它们混用** ——
    前两个会被 `_cleanup` 清掉，拿它们当累加器或首判都会静默失效，
    详见各自的注释。

只有"已发出的请求有了明确结论"才算完成。这样丢包、超时、
假人被推开这些情况都不会导致步骤被误判成成功。
"""

from __future__ import annotations

import json
import math
import time
from typing import Any, Callable

from .body import BodyController


class RealBodyActions:
    """给执行器用的真实假人步骤处理器。每个智能体一个实例。"""

    #: 同一个挖掘步骤最多重试多少次。超过就放弃，避免计划永远做不完。
    #:
    #: ⚠️ 曾经是 300：挖不动的方块（基岩/保护区域）每次要等挖掘超时
    #: （约 6.5 秒）+ 退避 1.5 秒，300 次要耗 30+ 分钟，期间控制台一直
    #: 有 bot:dig。30 次（约 3 分钟）足够区分"暂时被挡"和"真挖不动"。
    MAX_ATTEMPTS = 30

    #: 寻路失败的重试上限。比挖掘的小得多：走不到的原因绝大多数是
    #: "目标悬空/不可达"（比如挖高树时树干上段的落脚点在空中），
    #: 这种重试再多也不会成功；少量次数只是留给"临时被实体挡住"。
    #: 8 次 ×（寻路耗时 + 退避 1.5 秒）≈ 半分钟放弃，刷屏也可控。
    WALK_MAX_ATTEMPTS = 8

    #: 已经**明确失败过**的步骤，多久之后才允许再试（秒）。
    #:
    #: 为什么需要退避：执行器每 tick 都会回来问同一个步骤，而
    #: `DIG_TIMEOUT` 是 8 秒——一次挖不动的方块，会在 8 秒内被反复
    #: 发起 160 次左右，每一次都往控制台喷一条 `Script event bot:dig
    #: has been sent`。用户看到的就是日志刷屏。
    #:
    #: 退避只作用于"上次明确拿到了失败结论"的步骤，不碰"还没结论"的
    #: 情况，所以正常挖掘的节奏完全不变。
    RETRY_BACKOFF_SECONDS = 1.5

    def __init__(self, controller: BodyController, world: Any, logger: Any) -> None:
        self._ctl = controller
        self._world = world
        self._logger = logger
        #: 步骤键 → 已经尝试了几次
        self._attempts: dict[tuple, int] = {}
        #: 步骤键 → 该步骤当前的内部阶段（walk / dig / place）
        self._phase: dict[tuple, str] = {}
        #: 步骤键 → 这个步骤**累计**失败了几次。只增不减。
        #:
        #: ⚠️ 为什么不能用 `_attempts` 当累加器：它在每次拿到结论后都会被
        #: `_cleanup` 清掉，于是 `_attempts.get(key, 0) + 1` **永远是 1**。
        #: 那样 `n >= MAX_ATTEMPTS` 永不成立，"试够次数就放弃"这道闸彻底
        #: 失效 —— 一个挖不动的方块会被无限重发下去（日志刷屏永远不停），
        #: 而计划也永远等不到那个"放弃"的终态（智能体永久发呆）。
        #: 实测：连续追问 12 秒，`bot:dig` 始终只有 1 条，卡死在原地。
        self._tries: dict[tuple, int] = {}
        #: 已经**开始过**的步骤键。只增不减，和 `_attempts` 是两回事。
        #:
        #: `_attempts` 会在每次拿到结论后被 `_cleanup` 清掉，所以它答不了
        #: "这个步骤是不是第一次遇到"。多阶段处理器（`dig_far` / `place_real`）
        #: 必须靠这张表来区分"首次发起"和"等结论"，否则会退化成无限重发。
        self._started: set[tuple] = set()
        #: 步骤键 → 上次拿到失败结论的时间。用于退避。
        self._failed_at: dict[tuple, float] = {}
        #: 步骤键 → 是否已经**彻底放弃**。
        #:
        #: ⚠️ 这个表是修一个"计划永远卡死"的 bug 时加的，它解决的是
        #: **"还没完"和"完了但失败"被混为一谈**的问题。
        #:
        #: 处理器的返回值只有两种含义：
        #:     True  → 这一步成功了
        #:     False → 这一步还没结论（执行器会原地下次再问）
        #: 而"我已经试够了，这一步就是做不成"这个结论**没有第三个返回值
        #: 可用**。原先的处理是返回 False——于是执行器永远认为"还在进行中"，
        #: 计划既不推进也不结算，`_inflight` 永不释放，整个智能体从此发呆，
        #: 而且一行日志都不打（看起来就像"在执行完一次任务后不动了"）。
        #:
        #: 现在的约定：真的放弃了就把 key 记进这张表，并且**返回 True**。
        #: 返回 True 表示"这一步有结论了"，执行器推进游标、记一次失败、
        #: 计划照常走向 DONE/FAILED、`_inflight` 被正常回收。
        #: 调用方（`plugin._real_or_retry`）负责把一次失败记账成一次重试，
        #: 次数烧光后就不再重规划，所以不会变成无限循环。
        self._gave_up: dict[tuple, str] = {}
        #: 发起进食那一刻的血量。用来判断"到底吃到了没有"——
        #: `bridge.consume()` 没有回调，只能靠前后血量对比来确认。
        self._consume_before: float | None = None
        #: 最近一次攻击的回调结果。True/False 表示有结论，None 表示还在等。
        self._attack_result: bool | None = None
        self._attack_error = ""
        #: 最近一次容器操作（箱子/熔炉/工作台）的回调结果。
        self._container_result: bool | None = None
        self._container_error = ""
        #: 合成/熔炼产出（{"id": ..., "count": ...}），供上层反馈给模型。
        self._container_made: dict[str, Any] = {}

    def reset(self) -> None:
        self._attempts.clear()
        self._phase.clear()
        self._started.clear()
        self._tries.clear()
        self._failed_at.clear()
        self._gave_up.clear()
        self._consume_before = None
        self._attack_result = None
        self._attack_error = ""
        self._container_result = None
        self._container_error = ""
        self._container_made = {}

    # ------------------------------------------------------------------
    # "放弃了"的两种表达
    # ------------------------------------------------------------------

    def _give_up(self, key: tuple, reason: str) -> bool:
        """宣告这个步骤彻底做不成了。**返回 True** —— 见 `_gave_up` 的注释。

        为什么返回 True 而不是 False：执行器只认 True/False，而 False 被
        解释成"还没结论"。要让计划能够结算、让上层看到"这个方块就是挖不动"，
        唯一的办法就是回报一个明确的终态。
        """
        self._gave_up[key] = reason
        self._cleanup(key)
        self._logger.debug(f"[{self._ctl.name}] {key} 放弃：{reason}")
        return True

    def pop_gave_up(self, key: tuple) -> str:
        """取走"已放弃"标记（有就返回原因，没有就返回空串）。

        ⚠️ 一次性读取。调用方（插件）在把这次失败记进重试计数之后必须
        调它，否则下一轮会重复消耗重试次数（甚至连环触发）。返回 True
        之后紧接着就要收掉这个标记，这是调用约定的一部分。
        """
        return self._gave_up.pop(key, "")

    def key_of(self, step: Any) -> tuple:
        """算出这个步骤在 `_attempts` / `_gave_up` 里的键。

        和各个处理器开头算 key 的规则**必须一致**。调用方要按步骤查
        "它是不是刚被放弃了"，就得用同一个算法，所以把它抽出来当唯一
        真相来源，别在两处各写一遍。
        """
        op = getattr(step, "op", "")
        if op == "attack":
            return ("attack",)
        if op == "consume":
            return ("consume",)
        if op in ("walk_to",):
            return ("walk", step.x, step.y, step.z)
        if op in ("dig_far", "dig_near"):
            # ⚠️ 这两个 op 在处理器里用的都是 `digfar` 前缀（见 `dig_far`），
            # 别按 op 名字去猜。
            return ("digfar", step.x, step.y, step.z)
        if op == "place_real":
            return ("place", step.x, step.y, step.z)
        if op == "container":
            # 容器操作的键带 note（JSON），因为同一个容器方块可能做
            # 多次不同的操作，只按坐标会互相串味。
            return ("container", step.x, step.y, step.z, str(step.note))
        return (op, step.x, step.y, step.z)

    def _backing_off(self, key: tuple) -> bool:
        """这个步骤现在要不要重发。

        ⚠️ 返回 True 的**语义**很关键：它的意思是"**不用发，但这一步仍然
        没结论，执行器请下一 tick 再来问**"。所以返回 True 时调用方必须
        交回 `False`（"还没完"），绝不能交回 True —— 那会被当成成功。

        顺便一提，这个函数**故意不清 `_failed_at`**。原先的写法是"退避
        时间一到就把记录 pop 掉，允许重试"，看着挺合理，实际上是个计数
        黑洞：一旦 pop 掉，`_begin` 就会**重新从 1 开始计**，于是
        `MAX_ATTEMPTS` 永远到不了，"试 300 次就放弃"这道闸形同虚设，
        一个走不到的目标会被无限重规划下去（也就是用户看到的"日志刷屏"
        永远不会停）。现在改成只读取、不删除，次数才会真的累加、
        真的能烧光。

        另外，退避和"烧光次数"是**两道不同的闸**，位置也不同：
        退避只是本次不发，不消耗次数；次数是每拿到一次真实失败才 +1。
        两者都挡在"发起新尝试"这一格上，所以顺序永远是
        `_backing_off` → `_begin` → 真正发起。
        """
        if key in self._gave_up:
            return True                    # 已经判过死刑了，别再试
        failed = self._failed_at.get(key)
        if failed is None:
            return False
        return (time.monotonic() - failed) < self.RETRY_BACKOFF_SECONDS

    def _mark_failed(self, key: tuple) -> None:
        self._failed_at[key] = time.monotonic()

    def _bump(self, key: tuple) -> int:
        """给这个步骤的累计失败次数 +1，并返回新值。

        用 `_tries` 而不是 `_attempts`，因为后者会被 `_cleanup` 清空，
        累加出来的永远是个 1（详见 `_tries` 的注释）。
        """
        n = self._tries.get(key, 0) + 1
        self._tries[key] = n
        return n

    def _fail_or_give_up(self, key: tuple, limit: int, why: str) -> bool:
        """记一次失败：还没到上限就返回 False（下次再试），到了就放弃。

        两个返回值对应处理器的两种语义，调用方直接 `return` 即可。

        ⚠️ 退避期内**直接返回、什么都不记**。这一条是必须的，否则会出
        两个叠加的毛病：

          · `_mark_failed` 会把退避时间戳往后推，等于**自己重置自己的
            退避** —— 上次失败刚设的 1.5 秒，这次进来又推 1.5 秒，
            退避永远不起作用
          · 执行器是每 tick 来问一次的，不挡住的话 `_tries` 会以
            **每秒 20 次**的速度往上涨，几次重试的额度在零点几秒内就
            烧光了 —— "试 4 次再放弃"实际变成了"试 0.2 秒就放弃"

        实测：加这道闸之前，4 次额度在 **0.00 秒**内烧完；加了之后，
        每次重试之间稳定隔 `RETRY_BACKOFF_SECONDS`。

        ⚠️ 计数用的是 `_tries`（只增不减），不是 `_attempts`。用后者的话
        每次 `_cleanup` 一清，累加出来的就永远是 1，`limit` 形同虚设 ——
        一个挖不动的方块会被无限重发，"放弃"这个终态永远到不了，
        计划也就永远卡在 `_inflight` 里。
        """
        if self._backing_off(key):
            return False
        n = self._bump(key)
        self._mark_failed(key)
        if n >= limit:
            return self._give_up(key, f"{why}（第 {n} 次）")
        self._logger.debug(f"[{self._ctl.name}] {why}")
        return False

    def _retry_later(self, key: tuple, limit: int, why: str) -> bool:
        """多阶段处理器（`dig_far` / `place_real`）失败时的统一出口。

        为什么单独起个名字、而不直接叫 `_fail_or_give_up`：多阶段处理器的
        失败分支**不在函数开头**，绕过了 `issue()` 那两道闸，所以这里是
        它们唯一能碰到退避闸的地方。名字不同是在提醒后来者：
        "走到这一行说明已经拿到失败结论了，别再加一层 cond"。

        行为上它和 `_fail_or_give_up` 一致（退避期内不记账、超限就放弃）。
        """
        return self._fail_or_give_up(key, limit, why)

    # ------------------------------------------------------------------
    # 对外：一个步骤到底完成了没有
    # ------------------------------------------------------------------

    def step_done(self, key: tuple) -> bool:
        """这个步骤是否已经到了有结论的状态。

        ⚠️ **目前没有任何调用点**，是留给外部查询的探针。留着它的同时
        把判据写对：不能拿 `_attempts` 判（它只表示"本轮进行中"，
        而且会被 `_cleanup` 清掉），得用只增不减的 `_started`。
        """
        ctl = self._ctl
        if ctl.busy:
            return False
        if key in self._gave_up:
            return True                    # 已放弃也是个"有结论"
        return key in self._started

    # ------------------------------------------------------------------
    # 通用：发起 / 收尾
    # ------------------------------------------------------------------

    def issue(self, key: tuple, *, limit: int | None = None) -> bool | None:
        """发起一次尝试的通用前置。**三态返回**，务必看清：

            None  → 闸都过了，请继续往下发起
            False → 这次不发，但**这一步仍然没结论**，执行器下 tick 再来问
            True  → 这一步已经**彻底放弃**，这是个终态，请交回执行器结算

        把两道闸收在一个地方，是为了让每个处理器开头长得一模一样、
        不会有谁漏掉其中一道。三道判定依序是：
          · 已经判过死刑（`_gave_up`）
          · 还在退避期里
          · 尝试次数烧光了 —— 只有这种情况会**挂着"放弃"标记返回 True**

        ⚠️ 这套三态是重试逻辑里最容易写错的地方。踩过的坑就是最后那条：
        次数烧光之后如果仍然返回 False（"还没结论"），执行器会永远等下去，
        计划既不推进也不结算，`_inflight` 永不释放，整个智能体从此发呆，
        而且一行日志都不打 —— 用户看到的就是"执行完一次任务后就不动了"。
        集中在这里比散在六个处理器里安全得多。

        ⚠️ 另一处同样致命的写法错误：**已经判过死刑的步骤必须返回 True**。
        这一条曾经写漏过 —— 当时的写法是"`_backing_off` 为真就返回 False"，
        而 `_backing_off` 把"还在退避"和"已经放弃"两件事**混在一个
        bool 里**。后果是：第一次宣告放弃时确实返回了 True（计划正常
        结算），但**如果执行器再问一次**，它就会退化成"还没结论" ——
        一个永久的进行中状态。

        为什么这很容易被漏掉：正常路径下执行器收到 True 就推进游标，
        不会再问第二次，所以看上去一切正常。但有两类情况会再问：
        `Plan.note_failed()` 记账后计划层若有别的机制回头，或者
        `_real_or_retry` 没能消耗掉放弃标记。一旦发生，计划就**永久卡死**，
        而日志上只能看到一句"某步骤放弃"，之后什么都没有。

        现在的写法是先把 `True` 这个终态还回去，再去看退避。
        """
        cap = self.MAX_ATTEMPTS if limit is None else limit
        if key in self._gave_up:
            # 终态优先。**必须**排在退避判定前面 —— 这两件事的返回值
            # 语义完全相反（True = 有结论了，False = 还没结论），
            # 合在一起判就一定会写错。
            return True
        if self._backing_off(key):
            return False
        if not self._begin(key, cap):
            n = self._attempts.get(key, 0)
            self._cleanup(key)
            return self._give_up(key, f"重试 {n} 次仍未成功（上限 {cap}）")
        return None

    def _begin(self, key: tuple, limit: int | None = None) -> bool:
        """登记一次尝试。返回 False 表示已经超过上限。

        ⚠️ 注意这里是"登记"，不是"判定"。它**不**负责宣告放弃——
        宣告要走 `_give_up`，因为那需要返回一个 True 给执行器。
        """
        cap = self.MAX_ATTEMPTS if limit is None else limit
        n = self._attempts.get(key, 0) + 1
        self._attempts[key] = n
        return n <= cap

    def _cleanup(self, key: tuple) -> None:
        """清掉这个步骤的**进行中**状态，但保留失败记账。

        `_phase` 和 `_attempts` 都是"这一轮"的东西，结论出来就该清。
        但 `_failed_at` 必须留着：它记录的"这一步刚刚失败过"，正是
        下一步重试时要用的退避依据。一起清掉的话，退避就成了摆设。
        """
        self._attempts.pop(key, None)
        self._phase.pop(key, None)

    def _phase_of(self, key: tuple) -> str:
        return self._phase.get(key, "")

    def _set_phase(self, key: tuple, value: str) -> None:
        self._phase[key] = value

    # ------------------------------------------------------------------
    # 挖掘
    # ------------------------------------------------------------------

    def dig_near(self, step: Any) -> bool:
        """假人已经站得够近，直接挖。

        ⚠️ 判"第一次"用 `_started`、不用 `_attempts`。理由和 `walk_to`
        的docstring里那段一样：`_attempts` 会被 `_cleanup` 清掉，而重新
        登记它的唯一入口 `issue()` 可能被退避闸挡下（挡下时不登记），
        于是 `key not in self._attempts` 永远成立 —— 每一轮都在"首次
        发起"和"被闸挡下"之间循环，那条失败重试的路永远走不到。

        ⚠️ "记账"和"重发"必须分开，绝不能在同一轮：
           · 拿到失败结论 → 只记账（`_retry_later`，它会设退避）
           · 没有结论 → 只重发（`issue` 判退避，退避期过了才放行）
        旧版把两件事写在同一轮（记账后立刻 `_reissue`），而 `_reissue`
        的 `issue` 会撞上记账刚设的退避 —— 于是"重发"永远轮不到，
        dig 只发最初那 1 条，`tries` 一路涨到上限后直接放弃。
        """
        key = ("dig", step.x, step.y, step.z)
        ctl = self._ctl

        # 第一次遇到：发起
        if key not in self._started:
            pre = self.issue(key)
            if pre is not None:
                return pre
            self._started.add(key)
            ctl.clear_dig_result()      # 别读到上一步留下的旧结论
            if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
                self._cleanup(key)
                return False
            return False        # 刚发起，还没结论

        if ctl.busy:
            return False        # 还在挖

        # 读结论
        result = ctl.dig_result_for(step.x, step.y, step.z)
        if result is not None:
            ctl.clear_dig_result()      # 消费掉，否则下一轮重演同一条
            self._cleanup(key)
            if result.ok:
                return True
            # 明确失败：只记账（设退避），**不重发**。下一轮"无结论"
            # 时会走到下面的重发分支，由 `issue` 在退避期过后放行。
            return self._retry_later(
                key, self.MAX_ATTEMPTS,
                f"挖掘 ({step.x},{step.y},{step.z}) 失败: {result.error}")

        # 没有对应结论（可能结论还没到 / 被别的动作挖掉了）。
        self._cleanup(key)
        if not self._world.is_solid_id(step.x, step.y, step.z):
            return True                 # 方块没了，算完成

        # 方块还在、又没有新结论 → 重发。这里**不记账**：没有结论就不算
        # 失败，不能烧重试额度；`issue` 会在退避期内返回 False（等），
        # 退避期过后才真正发出下一次挖掘。
        pre = self.issue(key)
        if pre is not None:
            return pre
        ctl.clear_dig_result()
        if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
            self._cleanup(key)
            return False
        return False        # 刚发出去，等下一轮读结论

    def dig_far(self, step: Any) -> bool:
        """先走过去，到了再挖。

        这是"不隔墙挖方块"的核心：假人必须真的移动到方块旁边才会动手。
        从计划的角度看这仍是一个原子步骤——执行器不关心里面分了几段。

        ⚠️ 这里用 `_started` 而不是 `_attempts` 来判"是不是第一次"。
        这个区别是整个函数能走完的关键：

            `_attempts` 是"**正在进行**的一次尝试"，结论一出来就被
            `_cleanup` 清掉。拿它当"发起过没有"的判据，会在拿到结论的
            下一轮又变回"第一次"——于是重新 `clear_dig_result()`，
            把**刚刚拿到的结论扔掉**，再发一次请求…… 结论永远读不到，
            方块永远挖不掉，计划永远停在这一步。
            实测：连续追问 6 秒，`bot:dig` 只有最初那 1 条。

            `_started` 是"这个坐标**曾经**开始过"，只增不减，所以
            "第一次"只可能是真的第一次。
        """
        key = ("digfar", step.x, step.y, step.z)
        ctl = self._ctl

        if key not in self._started:
            pre = self.issue(key)
            if pre is not None:
                return pre
            self._started.add(key)
            if self._within_reach(step.x, step.y, step.z):
                self._set_phase(key, "dig")
                ctl.clear_dig_result()
                if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
                    self._cleanup(key)
                    return False
            else:
                self._set_phase(key, "walk")
                tx, ty, tz = self._approach_point(step.x, step.y, step.z)
                if not ctl.start_walk(tx, ty, tz):
                    self._cleanup(key)
                    return False
            return False

        if ctl.busy:
            # 走的半路上如果已经够得着目标方块了，就不必等寻路走完——
            # 立刻停下转挖。挖高树时尤其明显：approach 点可能算在树干
            # 高处，但假人走到半途就已经够得着低处的原木了。
            # `ctl.cancel` 会发 bot:stop（JS 侧 stopMoving + 清寻路轮询），
            # 留下的 walk 失败结论用 clear_walk_result 清掉。
            if self._within_reach(step.x, step.y, step.z):
                ctl.cancel("半路已经够得着，提前开挖")
                ctl.clear_walk_result()
                self._set_phase(key, "dig")
                ctl.clear_dig_result()
                if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
                    self._cleanup(key)
                    return False
                return False
            return False

        phase = self._phase_of(key)

        if phase == "walk":
            # 走完了吗？用**真实坐标**判断，不是"指令发出去了就算到"。
            if self._within_reach(step.x, step.y, step.z):
                self._set_phase(key, "dig")
                ctl.clear_dig_result()
                if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
                    self._cleanup(key)
                    return False
                return False
            # 还没走到。看有没有**新的**寻路结论。
            last = ctl.last_walk
            if last is not None:
                ctl.clear_walk_result()      # 消费掉，否则下一轮重演同一条
                if not last.ok:
                    # 寻路失败：只记账（设退避），**不重发**。下一轮
                    # "无结论"时会走到下面的重发，由 `issue` 放行。
                    # ⚠️ 这里不能 `_cleanup(key)` —— 那会清掉 phase，
                    # 下一轮落到"重新发起挖掘"分支，假人原地对着远处
                    # 方块空挖（正是用户看到的"挖方块不走动"）。
                    return self._retry_later(
                        key, self.WALK_MAX_ATTEMPTS,
                        f"靠近 ({step.x},{step.y},{step.z}) 失败: {last.error or '未知'}")
                # last.ok=true 但没够着 → 走完没够着，落到下面的重发。

            # 没有新结论（已消费），或"走完了却没够着"：重发一次寻路。
            # 保持 phase=walk；`issue` 会在退避期内返回 False（等）。
            pre = self.issue(key)
            if pre is not None:
                return pre
            tx, ty, tz = self._approach_point(step.x, step.y, step.z)
            if not ctl.start_walk(tx, ty, tz):
                self._cleanup(key)
                return False
            return False

        # 走到这里说明既不是第一次，也不是"正要靠近"——那就是"在挖，
        # 或者刚挖完还没读结论"。两件事都得做，而且**顺序不能反**：
        # 先读结论，再决定要不要重新发起。
        #
        # ⚠️⚠️ 这一段是整份重试逻辑里最阴的一个坑，两个毛病叠在一起
        # 才显形，单独看任何一个都不像 bug：
        #
        #   1）`ctl.dig_result_for()` 是**只读**的，不是"取走"。它每次
        #      都返回 `last_dig` 这条记录，`last_dig` 又一直躺在那儿。
        #      所以"读到失败结论 → 记一次失败 → return"这个写法，在
        #      **下一轮会原封不动地重演一遍** —— 同一句 `result.error`
        #      被当成新失败记了 N 次。
        #
        #   2）更要命的是那个 `return`：它让下面的"重新发起"**永远轮
        #      不到**。函数看着是对称的（"上面负责发，下面负责收"），
        #      实际是条断头路。实测：`bot:dig` 永远停在 1 条，`tries`
        #      一路涨到上限，然后宣告放弃 —— 一个本来完全能挖掉的方块
        #      就这么被判了死刑，计划还卡在 `_inflight` 里出不来。
        #
        # 所以这里的写法是：**读完就消费掉**（`clear_dig_result()`），
        # 让"这条结论"和"这次尝试"严格一对一；只有真的拿到结论的那一
        # 轮才记账，其余轮次一律落到下面的"重新发起"。
        result = ctl.dig_result_for(step.x, step.y, step.z)
        if result is not None:
            self._cleanup(key)
            ctl.clear_dig_result()      # ← 消费掉，否则下一轮重演
            if result.ok:
                return True
            # 拿到明确失败：记账（含退避）。这一轮到此为止，下一轮
            # 走到下面的"重新发起"去重试。
            return self._retry_later(
                key, self.MAX_ATTEMPTS,
                f"挖掘 ({step.x},{step.y},{step.z}) 失败: {result.error}")

        if not self._world.is_solid_id(step.x, step.y, step.z):
            self._cleanup(key)
            return True

        # 没有结论、方块也还在 → 上一轮发起的尝试已经结算完了（或者
        # 结论早被消费掉），该重新发一次。重新发起要重新过退避闸和
        # 次数闸，所以先 `_cleanup` 把"进行中"清干净。
        #
        # ⚠️ `_cleanup` 不能顺手清掉 `_failed_at` —— 那正是退避闸的
        # 依据，也是"tries 能累加"的前提（见 `_cleanup` 的注释）。
        self._cleanup(key)
        pre = self.issue(key)
        if pre is not None:
            return pre
        if not ctl.start_dig(step.x, step.y, step.z, tool=step.note):
            # 没发出去（正忙 / 去重闸拦下）。这不是结论，清掉这次
            # 尝试下轮再来；**不要**记失败，否则去重闸挡一次就多
            # 烧一次重试额度。
            self._cleanup(key)
            return False
        return False        # 刚发出去，等下一轮读结论

    # ------------------------------------------------------------------
    # 移动
    # ------------------------------------------------------------------

    def walk_to(self, step: Any) -> bool:
        """走到某处。中途失败会重试，重试烧光后**明确交出失败**。

        ⚠️ 两个最容易写错的点，都在本函数的注释里踩过：

        1. **判"第一次"必须用 `_started`，不能用 `_attempts`**——后者会被
           `_cleanup` 清掉，而重登记它的唯一入口 `issue()` 又可能被退避闸
           挡下（挡下时不登记），于是"第一次"判据永远成立，每一轮都在
           "首次发起"和"被闸挡下"之间空转。实测 1200 tick 追问，
           `bot:walk` 只有 1 条，一等等到天荒地老。

        2. **"记账"和"重发"必须分轮**——拿到失败结论的那一轮只记账
           （`_fail_or_give_up` 会设退避），**不重发**；下一轮读不到新结论
           时，由 `issue()` 在退避期过后放行重发。旧版把两件事写在同一轮
           （记账后立刻重发），重发撞上刚设的退避，`bot:walk` 永远只有
           最开始那 1 条、`tries` 却一路涨到上限后放弃。
        """
        key = ("walk", step.x, step.y, step.z)
        ctl = self._ctl

        if key not in self._started:
            pre = self.issue(key, limit=self.WALK_MAX_ATTEMPTS)
            if pre is not None:
                return pre
            self._started.add(key)
            if not ctl.start_walk(step.x, step.y, step.z):
                # 没发出去（正在忙/桥接断了）。这不是"结论"，清掉这次
                # 尝试，下一 tick 再来——但不能记失败，否则会把退避闸
                # 打开，反而拖慢正常的重试。
                self._cleanup(key)
                return False
            return False

        if ctl.busy:
            return False                       # 还在走，没结论

        # 用真实坐标判断到没到，而不是"指令发出去了就算到了"。
        pos = self._actor_position()
        if pos is not None:
            d = math.dist(pos, (step.x + 0.5, step.y, step.z + 0.5))
            if d <= 2.5:
                self._cleanup(key)
                return True

        # 没走到（或读不到坐标）。看有没有**新的**寻路结论。
        last = ctl.last_walk
        if last is not None:
            ctl.clear_walk_result()      # 消费掉，否则下一轮重演同一条
            self._cleanup(key)
            if pos is None and last.ok:
                return True               # 读不到坐标，只能信寻路结论
            if not last.ok:
                # 寻路失败：只记账（设退避），下一轮"无结论"时重发。
                return self._fail_or_give_up(
                    key, self.WALK_MAX_ATTEMPTS,
                    f"移动失败: {last.error or '未知'}")
            # last.ok=true 但没走到（坐标有值且还差得远）→ 走完没够着，
            # 落到下面的重发。

        # 没有新结论（已消费），或"走完了却没够着"：重发。这里**不记账**
        # （没有失败结论就不烧额度）；`issue` 会在退避期内返回 False（等），
        # 退避期过了才真正发出下一次寻路。
        pre = self.issue(key, limit=self.WALK_MAX_ATTEMPTS)
        if pre is not None:
            return pre
        if not ctl.start_walk(step.x, step.y, step.z):
            self._cleanup(key)
            return False
        return False

    # ------------------------------------------------------------------
    # 放置
    # ------------------------------------------------------------------

    #: 放置最多试几次。放置是瞬时的，不像挖掘要等好几秒，
    #: 所以不需要 `MAX_ATTEMPTS` 那么多次。
    PLACE_MAX_ATTEMPTS = 3
    #: 进食最多试几次。血量没涨最常见的原因就是"本来就满血"或
    #: "手上没食物"，这两种再试多少次都一样。
    CONSUME_MAX_ATTEMPTS = 2

    def place_real(self, step: Any) -> bool:
        key = ("place", step.x, step.y, step.z)
        ctl = self._ctl
        limit = self.PLACE_MAX_ATTEMPTS

        if key not in self._started:
            pre = self.issue(key, limit=limit)
            if pre is not None:
                return pre
            # ⚠️ 和 `dig_far` 同理：判"第一次"必须用 `_started` 而不是
            # `_attempts`。用后者的话，拿到"没放上"的结论之后会被判成
            # 又一次"第一次"，`_set_phase` 会把已有的阶段覆盖掉，
            # 来回在 walk/place 之间打转，永远放不下去。
            self._started.add(key)
            if self._within_reach(step.x, step.y, step.z):
                self._set_phase(key, "place")
                self._send_place(step)
            else:
                self._set_phase(key, "walk")
                tx, ty, tz = self._approach_point(step.x, step.y, step.z)
                if not ctl.start_walk(tx, ty, tz):
                    self._cleanup(key)
                    return False
            return False

        if ctl.busy:
            return False

        phase = self._phase_of(key)

        if phase == "walk":
            if self._within_reach(step.x, step.y, step.z):
                self._set_phase(key, "place")
                self._send_place(step)
                return False
            # 还没走到。看有没有**新的**寻路结论。
            last = ctl.last_walk
            if last is not None:
                ctl.clear_walk_result()      # 消费掉，否则下一轮重演同一条
                if not last.ok:
                    # 寻路失败：只记账，下一轮"无结论"时重发。
                    # ⚠️ 不 `_cleanup(key)` —— 清了 phase 会误入 place 阶段。
                    return self._retry_later(
                        key, self.WALK_MAX_ATTEMPTS,
                        f"走近 ({step.x},{step.y},{step.z}) 失败: {last.error or '未知'}")
                # last.ok=true 没够着 → 落到下面的重发。
            # 重发 walk（issue 判退避）。
            pre = self.issue(key, limit=limit)
            if pre is not None:
                return pre
            tx, ty, tz = self._approach_point(step.x, step.y, step.z)
            if not ctl.start_walk(tx, ty, tz):
                self._cleanup(key)
                return False
            return False

        # place 阶段：放置很快，用方块状态确认就够了。
        ok = self._world.is_solid_id(step.x, step.y, step.z)
        if ok:
            self._cleanup(key)
            return True
        # 没放上。这是**状态型**失败（方块一直不在），没有"新/旧结论"
        # 之分，所以用退避来区分"记账"和"重发"：
        if self._backing_off(key):
            self._cleanup(key)
            return False            # 退避期内，等
        if key in self._failed_at:
            # 失败过且退避期过了 → 重发（清掉失败标记，重新计退避）。
            self._failed_at.pop(key, None)
            self._cleanup(key)
            self._send_place(step)
            return False
        # 首次失败 → 记账（设退避）。
        self._cleanup(key)
        return self._fail_or_give_up(
            key, limit, f"放置 ({step.x},{step.y},{step.z}) 没放上")

    def _send_place(self, step: Any) -> None:
        """发一条放置请求。不需要等回调——用方块状态判定结果。"""
        self._ctl._bridge.place(  # noqa: SLF001
            self._ctl.name, step.x, step.y, step.z,
            step.block or "minecraft:cobblestone",
            callback=lambda ok, err, info: None,
        )

    # ------------------------------------------------------------------
    # 进食
    # ------------------------------------------------------------------

    def consume_real(self, step: Any) -> bool:
        """让假人吃点东西回血。

        ⚠️ 这里**不写** `actor.health = ...`。

        2.x 是在 Python 侧直接把血量加上去的，那是"隔空改状态"：
        客户端不会看到任何进食动作，而且绕过了饥饿度——假人可以
        永远不吃饭却一直满血。交给 JS 侧用 `consume` 真吃一口，
        血量由引擎自己结算。

        ⚠️ 这里**不能**像 `dig_near` 那样"发出去就算数"。
        `bridge.consume()` 返回的是 `bool`（命令有没有发出去），
        不是 `req_id`——它压根没有回调。所以收到的 `True` 只代表
        "指令发出去了"，不代表"假人真的吃到了"。要是把它当成成功，
        血没回上去也会被记成完成，模型下一轮会以为已经吃饱了。

        判定依据只能是**血量有没有涨**。所以这里记下发起时的血量，
        下一轮读一次比对。
        """
        key = ("consume",)
        ctl = self._ctl
        limit = self.CONSUME_MAX_ATTEMPTS

        if key not in self._started:
            pre = self.issue(key, limit=limit)
            if pre is not None:
                return pre
            self._started.add(key)
            before = self._health()
            ok = ctl._bridge.consume(  # noqa: SLF001
                ctl.name, getattr(step, "note", "") or "",
            )
            if not ok:
                # 命令根本没发出去（桥接断了/被拒）。直接失败，
                # 不要把这次尝试留在账上等一个永远不会来的血量变化。
                self._cleanup(key)
                return self._fail_or_give_up(key, limit, "进食指令发不出去")
            self._consume_before = before
            return False        # 刚发起，等下一轮看血量

        # 有结论了吗：血量涨了就成功。
        now_hp = self._health()
        before = self._consume_before
        if now_hp is not None and before is not None and now_hp > before:
            self._cleanup(key)
            return True
        # 没涨（或读不到）。状态型失败：用退避区分"记账"和"重发"。
        if self._backing_off(key):
            self._cleanup(key)
            return False            # 退避期内，等
        if key in self._failed_at:
            # 失败过且退避期过了 → 再吃一口。
            self._failed_at.pop(key, None)
            self._cleanup(key)
            self._consume_before = self._health()
            ctl._bridge.consume(  # noqa: SLF001
                ctl.name, getattr(step, "note", "") or "")
            return False
        # 首次失败 → 记账。
        if now_hp is None or before is None:
            why = "读不到血量，无法确认进食结果"
        else:
            why = f"进食后血量没变（{before} → {now_hp}），可能是血量已满或手上没食物"
        self._cleanup(key)
        return self._fail_or_give_up(key, limit, why)

    def _health(self) -> float | None:
        """读一下假人的当前血量。读不到返回 None。"""
        actor = self._ctl.actor
        if actor is None:
            return None
        try:
            v = getattr(actor, "health", None)
        except Exception:
            return None
        if v is None:
            return None
        try:
            return float(v)
        except (TypeError, ValueError):
            return None

    # ------------------------------------------------------------------
    # 攻击
    # ------------------------------------------------------------------

    #: 一次攻击最多重试几次。攻击有冷却，重试太快只会一直拿到"冷却中"。
    ATTACK_MAX_ATTEMPTS = 5

    def attack_real(self, step: Any) -> bool:
        """让假人挥拳打一下目标。

        判定为什么要等回调
        ------------------
        JS 侧的 `doAttack` 会做几件事：按 typeId 找最近的实体、量距离
        （超过 4.5 格直接返回"够不着"）、检查攻击冷却。这三种情况都会
        返回 `ok: false`，**一个伤害都没造成**。

        2.x 的写法是 `rid >= 0` 就 `return True`——只确认了"消息发出去了"，
        完全没看结果。于是"目标在 20 格开外"这种最平常的失败会被记成
        成功，模型下一轮会以为已经打到了，然后基于这个假前提继续决策。

        所以这里走和 `dig_near` 一样的"发起 + 等结论"模型：
        先把请求发出去，回调到达后才给出真正的成败。
        """
        key = ("attack",)
        ctl = self._ctl
        target = getattr(step, "note", "")

        if key not in self._started:
            pre = self.issue(key, limit=self.ATTACK_MAX_ATTEMPTS)
            if pre is not None:
                return pre
            self._started.add(key)
            self._attack_result = None
            rid = ctl._bridge.attack(  # noqa: SLF001
                ctl.name, target,
                callback=self._on_attack_done,
            )
            if rid < 0:
                # 命令根本没发出去。清掉这次尝试并记失败，
                # 让退避闸挡住后续的重发。
                self._cleanup(key)
                return self._fail_or_give_up(
                    key, self.ATTACK_MAX_ATTEMPTS, "攻击指令发不出去")
            return False        # 刚发起，等回调

        # 读结论（回调到达后 `_attack_result` 才有值）。
        result = self._attack_result
        if result is not None:
            self._attack_result = None      # 消费，否则下一轮重演同一条
            self._cleanup(key)
            if result is True:
                return True
            why = self._attack_error or "未知原因"
            # 失败：只记账，下一轮"无结论"时由 issue 放行重发。
            return self._fail_or_give_up(
                key, self.ATTACK_MAX_ATTEMPTS, f"攻击 {target} 失败: {why}")
        # 无结论（回调还没到，或退避期过了该重发）：重发由 issue 判退避。
        pre = self.issue(key, limit=self.ATTACK_MAX_ATTEMPTS)
        if pre is not None:
            return pre
        self._attack_result = None
        rid = ctl._bridge.attack(  # noqa: SLF001
            ctl.name, target, callback=self._on_attack_done)
        if rid < 0:
            self._cleanup(key)
        return False

    def _on_attack_done(self, ok: bool, err: str, _info: dict) -> None:
        """攻击回调。跑在服务器主线程的事件处理里，不能阻塞。"""
        self._attack_result = bool(ok)
        self._attack_error = str(err or "")

    # ------------------------------------------------------------------
    # 容器交互（箱子 / 熔炉 / 工作台）
    # ------------------------------------------------------------------

    #: 容器操作失败最多重试几次。失败通常是"缺材料 / 配方无效 / 没有
    #: 容器"，重试不会改变结果，所以给个很小的数，别再像挖掘那样试很久。
    CONTAINER_MAX_ATTEMPTS = 2

    def container_op(self, step: Any) -> bool:
        """对某个方块容器做操作（存/取/合成/熔炼）。

        `step.note` 是一段 JSON，字段随操作不同：
          · {"op":"put","item":...,"count":...}
          · {"op":"take","item":...,"count":...}
          · {"op":"smelt","input":...,"fuel":...,"count":...}
          · {"op":"craft","slots":[{"slot":0,"id":...},...]}

        走和 attack 一样的"发起 + 等回调"两拍：容器操作对假人是异步的
        （合成/熔炼要等引擎产出），不能"发出去了就算成功"。
        """
        key = ("container", step.x, step.y, step.z, str(step.note))
        ctl = self._ctl

        if key not in self._started:
            pre = self.issue(key, limit=self.CONTAINER_MAX_ATTEMPTS)
            if pre is not None:
                return pre
            self._started.add(key)
            self._container_result = None
            self._container_error = ""
            self._container_made = {}
            try:
                spec = json.loads(str(step.note or "{}"))
            except Exception:
                spec = {}
            rid = ctl._bridge.container(  # noqa: SLF001
                ctl.name, step.x, step.y, step.z, spec,
                callback=self._on_container_done)
            if rid < 0:
                self._cleanup(key)
                return self._fail_or_give_up(
                    key, self.CONTAINER_MAX_ATTEMPTS, "容器指令发不出去")
            return False        # 刚发起，等回调

        result = self._container_result
        if result is not None:
            self._container_result = None
            self._cleanup(key)
            if result is True:
                return True
            why = self._container_error or "容器操作失败"
            return self._fail_or_give_up(
                key, self.CONTAINER_MAX_ATTEMPTS, why)
        # 无结论（回调还没到）：等。
        return False

    def _on_container_done(self, ok: bool, err: str, info: dict) -> None:
        """容器操作回调。跑在服务器主线程，不能阻塞。"""
        self._container_result = bool(ok)
        self._container_error = str(err or "")
        made = info.get("made") if isinstance(info, dict) else None
        self._container_made = made if isinstance(made, dict) else {}

    def take_container_made(self) -> dict[str, Any]:
        """取走最近一次合成/熔炼的产出，供上层反馈给模型（一次性）。"""
        made = self._container_made
        self._container_made = {}
        return made

    # ------------------------------------------------------------------
    # 位置辅助
    # ------------------------------------------------------------------

    def _actor_position(self) -> tuple[float, float, float] | None:
        """假人的真实位置。"""
        actor = self._ctl.actor
        if actor is None:
            return None
        try:
            loc = actor.location
            return (loc.x, loc.y, loc.z)
        except Exception:
            return None

    def _within_reach(self, x: int, y: int, z: int) -> bool:
        """现在够不够得着。"""
        pos = self._actor_position()
        if pos is None:
            return False
        from .actions import ActionCompiler
        d = math.dist(pos, (x + 0.5, y + 0.5, z + 0.5))
        return d <= float(ActionCompiler.DIG_REACH)

    def _approach_point(self, x: int, y: int, z: int) -> tuple[int, int, int]:
        """给目标方块找一个能站人的相邻格。

        不能直接往方块本身走——那是要挖的固体。在它周围找一格
        脚下有东西、身体两格空的位置。

        ⚠️ "脚下有东西"这条不能省。曾经只查"这一格和上一格是空气"，
        结果挖高树时选中了**悬空格**（树干旁边的空中）——假人站在
        空气里是到不了那种格子的，`navigateToLocation` 对它规划不出
        完整路径，于是每条寻路都失败，假人原地不动、bot:walk 刷屏。
        """
        cands: list[tuple[int, int, int]] = []
        # 方向集合：同层侧向 + 低一层侧向 + 方块正上方。
        # ⚠️ 低一层侧向不能少：挖树干第二段（y+1）时，同层侧向格的脚下
        # 是空气（假人脚层），只有低一格的侧向格才踩在地面上。
        for dx, dy, dz in ((1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1),
                           (1, -1, 0), (-1, -1, 0), (0, -1, 1), (0, -1, -1),
                           (0, 1, 0)):
            nx, ny, nz = x + dx, y + dy, z + dz
            # 站人的条件是：这一格和上面一格都不是实体
            if self._world.is_solid_id(nx, ny, nz):
                continue
            if self._world.is_solid_id(nx, ny + 1, nz):
                continue
            # 且脚下有支撑（站空气里寻路到不了）。
            if not self._world.is_solid_id(nx, ny - 1, nz):
                continue
            cands.append((nx, ny, nz))

        if not cands:
            # 四面都堵着（比如正在挖实心岩层）——那就挖完之后再站过去，
            # 这里先返回方块上方，让寻路自己判断
            return (x, y + 1, z)

        pos = self._actor_position()
        if pos is None:
            return cands[0]
        return min(cands, key=lambda c: math.dist(pos, (c[0] + 0.5, c[1], c[2] + 0.5)))
